Segger emWin v5.48r for NXP Platforms
=====================================

These emWin library files were built using:

- arm-none-eabi-gcc gcc version 8 2018-q4-major
- IAR ANSI C/C++ Compiler V8.32.3.193/W32 for ARM
- Keil ARM C/C++ Compiler V5.06 update 6 (build 750) [MDK-ARM Professional 5.27.0.0]
- MCUXpresso IDE v11.0.0 [Build 2442] [2019-03-21]
